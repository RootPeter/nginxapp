/* for blowfish */
typedef struct {
    word32 S[4][256],P[18];
} blf_ctx;

